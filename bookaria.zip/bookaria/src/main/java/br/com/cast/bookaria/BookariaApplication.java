package br.com.cast.bookaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookariaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookariaApplication.class, args);
	}
}
